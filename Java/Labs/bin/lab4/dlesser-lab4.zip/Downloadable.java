package lab4;

public interface Downloadable {

	int INTERNET_SPEED_MBPS = 40;
	float download(int speed);
	
}
