//dlesser / Daniel Lesser
package lab9;

public abstract class Guest {
	
	int mealOrder;
	abstract void placeOrder();
	


}
