//Daniel Lesser / dlesser
package lab7;

import java.util.Objects;

public class Word implements Comparable<Word> {
	String word;
	String meaning;
	
	public Word(String word, String meaning) {
		super();
		this.word = word;
		this.meaning = meaning;
	}

	@Override
	public int hashCode() {
		return Objects.hash(word, meaning);
	}

	@Override
	public boolean equals(Object o) {
		if (o == null)
			return false;
		if (this == o)
			return true;
		if (getClass() != o.getClass())
			return false;
		Word w = (Word) o;
		return word.equals(w.word) && meaning.equals(w.meaning);

	}

	@Override
	public int compareTo(Word o) {
		return word.compareTo(o.word);
	}
	
}
