//Daniel Lesser / dlesser
package lab7;

public class Word {
	String word;
	String meaning;
	
	public Word(String word, String meaning) {
		super();
		this.word = word;
		this.meaning = meaning;
	}
	
}
